<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>usuarios </title>
</head>
<body>
  <!--USUARIO-->
<div class="container bg-success text-light" style="border-style: solid; width: 100vh;height: 345px;border-color:red; border-radius: 12px;">
      <form class="needs-validation"  novalidate>
        <br></br>
    <form novalidate>
  <div class="row">
    <div class="col">
        NOME COMPLETO
      <input type="text" class=" form-control" placeholder="Nome Completo "required>
      <div class="invalid-feedback">
          Por favor, escolha um nome de usuário.
        </div>
    </div>
    <div class="col-4">
      <!--<label for="inputEmail4">Email</label>-->
      EMAIL
      <input type="email" class="form-control" id="inputEmail4" placeholder="Email" required>
      <div class="invalid-feedback ">
          Por favor, escolha um E-mail
        </div>
    </div>
  </div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">MENSAGEM</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="MENSAGEM" required></textarea>
    <div class="invalid-feedback">
          Por favor, ensira uma mensagem 
        </div>
  </div>
  <div class="col-1">
<button type="submit" class="btn btn-primary"data-toggle="modal" data-target="#meuModal">ENVIAR</button>
</div>
</form>
</div>

<!--js-->
<script>
// Exemplo de JavaScript inicial para desativar envios de formulário, se houver campos inválidos.
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Pega todos os formulários que nós queremos aplicar estilos de validação Bootstrap personalizados.
    var forms = document.getElementsByClassName('needs-validation');
    // Faz um loop neles e evita o envio
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
          
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
</script>
<!--MONDAL DE MENSAGEM -->
<div class="modal fade" id="modal-mensagem">
   <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                
                <h4 class="modal-title text-danger">ERRO </h4>
            </div>
            <div class="modal-body text-danger">
                <p>TEM ALGUM DADOS NÃO PRENCIDOS ,VERIFICA </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>
<!--BOTÃO DE ABRIL O MODAL -->
<div>
<button class="btn btn-primary" data-toggle="modal" data-target="#modal-mensagem">
Exibir mensagem
</button>
</div>









<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>  

</body>
</html>